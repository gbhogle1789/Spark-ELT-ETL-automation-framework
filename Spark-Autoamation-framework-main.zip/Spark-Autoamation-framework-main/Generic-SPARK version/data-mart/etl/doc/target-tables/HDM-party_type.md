###Party_type


##PARTY_TYPE_CD

Party_type.PARTY_TYPE_CD


##PARTY_TYPE_NM

Party_type.PARTY_TYPE_NM


###Files Used

1. Party_type.csv (Pipe Delimited)


### File Location

internal/party_type.csv