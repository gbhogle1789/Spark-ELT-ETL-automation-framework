# DEALER_FEE_TYPE

This table holds the .
## DDL

|Column Name |SQL Type |Length |Nullable |Default Value |PK |
|---        |---     |---   |---   |--- |--- |
|[dlr_fee_type_cd](#dlr_fee_type_cd)|character varying|4|YES||NO
|[dlr_fee_type_desc](#dlr_fee_type_desc)|character varying|50|YES||NO
|[dlr_fee_type_key](#dlr_fee_type_key)|integer|(32,0)|NO||YES


### dlr_fee_type_key
#### Description



#### Value Range

N/A

#### Logic

Auto Increment Sequence Generator



### dlr_fee_type_cd
#### Description



#### Value Range

N/A

#### Logic


DLR_FEE_TYPE_CD



### dlr_fee_type_desc
#### Description



#### Value Range

N/A

#### Logic


DLR_FEE_TYPE_DESC




##Files Used
1. DEALER_FEE_TYPE.csv



