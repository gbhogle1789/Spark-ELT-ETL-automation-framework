##Social_codes



###ACCT_TYPE_CD	

Social_codes.ACCT_TYPE_CD



###CUST_ACCT_TYPE_NM

Social_codes.CUST_ACCT_TYPE_NM


###Files Used

1.Social_codes.csv


### Files Location

internal/social_codes.csv