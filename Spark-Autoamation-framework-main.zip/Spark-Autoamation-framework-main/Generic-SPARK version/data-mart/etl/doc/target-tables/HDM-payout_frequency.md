###payout_frequency


###FREQ_CD

payout_frequency.FREQ_CD

###FREQ_DESC

payout_frequency.FREQ_DESC

###FREQ_NBR

payout_frequency.FREQ_NBR



###Files Used
1. payout_frequency.csv (Pipe Delimited)
