###TIN_CODE


##TIN_CD_KEY	

TIN_CODE.TIN_CD_KEY



##TIN_CD	


TIN_CODE.TIN_CD



##TIN_DESC

TIN_CODE.TIN_DESC


###Files Used


1. TIN_CODE.csv



#### File Location

dstprod/TIN_CODE.csv