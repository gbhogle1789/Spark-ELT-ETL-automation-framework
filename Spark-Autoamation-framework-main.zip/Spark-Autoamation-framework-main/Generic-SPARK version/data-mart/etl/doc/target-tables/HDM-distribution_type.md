# DISTRIBUTION_TYPE

This table holds the lorem ipsum dolor sit amet.
## DDL

|Column Name |SQL Type |Length |Nullable |Default Value |PK |
|---        |---     |---   |---   |--- |--- |
|[dstrbtn_type_desc](#dstrbtn_type_desc)|character varying|100|YES||NO
|[dstrbtn_type_key](#dstrbtn_type_key)|integer|(32,0)|NO||YES
|[dstrbtn_type_cd](#dstrbtn_type_cd)|numeric|(38,15)|YES||NO
### dstrbtn_type_key
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### dstrbtn_type_cd
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### dstrbtn_type_desc
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



