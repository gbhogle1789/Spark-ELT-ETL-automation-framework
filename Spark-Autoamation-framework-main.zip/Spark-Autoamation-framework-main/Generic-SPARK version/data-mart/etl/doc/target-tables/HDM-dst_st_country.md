### DST_ST_COUNTRY



###dst_st_key

Auto Increment Sequence Generator



###st_crty_cd	

dst_st_country.st_crty_cd



###st_cd


dst_st_country.st_cd


###st_nm

dst_st_country.st_nm



###dst_st_cd	

dst_st_country.dst_st_cd



###crty_iso_cd	


dst_st_country.crty_iso_cd



###dst_crty_cd	


dst_st_country.dst_crty_cd



###crty_full_nm

dst_st_country.crty_full_nm





###Files Used

1. dst_st_country.csv


### File Location

internal/dst_st_country.csv
