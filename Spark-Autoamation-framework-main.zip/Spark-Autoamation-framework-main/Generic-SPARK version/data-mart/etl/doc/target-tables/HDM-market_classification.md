####market_classification


###MKT_CLSFCN_CD	


market_classification.MKT_CLSFCN_CD	


###MKT_CLSFCN_DESC


market_classification.MKT_CLSFCN_DESC


###Files Used

1. market_classification.csv



#### File Location

internal/market_classification.csv