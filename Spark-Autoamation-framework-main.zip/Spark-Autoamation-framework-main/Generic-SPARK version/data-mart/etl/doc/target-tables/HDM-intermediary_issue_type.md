# INTERMEDIARY_ISSUE_TYPE

This table holds the lorem ipsum dolor sit amet.
## DDL

|Column Name |SQL Type |Length |Nullable |Default Value |PK |
|---        |---     |---   |---   |--- |--- |
|[intrm_iss_type](#intrm_iss_type)|character varying|255|YES||NO
|[intrm_iss_type_key](#intrm_iss_type_key)|integer|(32,0)|NO||YES
### intrm_iss_type_key
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### intrm_iss_type
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



