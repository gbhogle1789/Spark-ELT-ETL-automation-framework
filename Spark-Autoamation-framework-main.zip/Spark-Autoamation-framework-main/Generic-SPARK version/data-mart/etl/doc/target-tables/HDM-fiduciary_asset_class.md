# FIDUCIARY_ASSET_CLASS

This table holds the lorem ipsum dolor sit amet.
## DDL

|Column Name |SQL Type |Length |Nullable |Default Value |PK |
|---        |---     |---   |---   |--- |--- |
|[fid_asset_cls_desc](#fid_asset_cls_desc)|character varying|255|YES||NO
|[fid_asset_cls_key](#fid_asset_cls_key)|integer|(32,0)|NO||YES
### fid_asset_cls_key
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### fid_asset_cls_desc
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



