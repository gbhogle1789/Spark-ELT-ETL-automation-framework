# MV_CURRENT_SHD_ACCT_BAL

This table holds the lorem ipsum dolor sit amet.
## DDL

|Column Name |SQL Type |Length |Nullable |Default Value |PK |
|---        |---     |---   |---   |--- |--- |
|[nbr_acct](#nbr_acct)|numeric|(38,15)|YES||NO
|[nbr_fund](#nbr_fund)|numeric|(38,15)|YES||NO
|[current_acct_bal](#current_acct_bal)|numeric|(38,15)|YES||NO
### nbr_acct
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### nbr_fund
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### current_acct_bal
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



