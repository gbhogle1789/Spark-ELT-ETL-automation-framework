# PERF_RUN_TYPE

This table holds the .
## DDL

|Column Name |SQL Type |Length |Nullable |Default Value |PK |
|---        |---     |---   |---   |--- |--- |
|[run_type_cd](#run_type_cd)|character varying|25|YES||NO
|[run_type_desc](#run_type_desc)|character varying|100|YES||NO
|[perf_run_type_key](#perf_run_type_key)|integer|(32,0)|NO||YES
### perf_run_type_key
#### Description



#### Value Range

N/A

#### Logic

PERF_RUN_TYPE_KEY



### run_type_cd
#### Description



#### Value Range

N/A

#### Logic

RUN_TYPE_CD




### run_type_desc
#### Description



#### Value Range

N/A

#### Logic

RUN_TYPE_DESC


## 
File Name: perf_run_type.csv
File Type: Comma Delimited
File Path : https://datalake-fileprocbucket-g5v3fkn4q5et.s3.us-east-2.amazonaws.com/fund/perf_run_type.csv




