# EXPENSE_RATIO_WAIVER_TYPE

This table holds the lorem ipsum dolor sit amet.
## DDL

|Column Name |SQL Type |Length |Nullable |Default Value |PK |
|---        |---     |---   |---   |--- |--- |
|[expns_ratio_wavr_type_cd](#expns_ratio_wavr_type_cd)|character varying|3|NO||NO
|[wavr_type_desc](#wavr_type_desc)|character varying|255|YES||NO
|[expns_ratio_wavr_type_key](#expns_ratio_wavr_type_key)|integer|(32,0)|NO||YES
### expns_ratio_wavr_type_key
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### expns_ratio_wavr_type_cd
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



### wavr_type_desc
#### Description

Lorem ipsum dolor sit amet

#### Value Range

N/A

#### Logic

Hybrid of sequence generator and source value from HDM.FUND id.

```
Autoincrement +1 for new inserts
```



