|	Source File Name	|	Column Name	|	Data Type	|	Length	|	Precision	|	Nullable	|	PK	|	BK	|		|		|		|		|	Target Table Name	|	Column Name	|	Data Type	|	Length	|	Nullable	|	PK	|
|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|
|		|		|		|		|		|		|		|		|		|		|	Update the record if already exists	|		|		|		|		|		|		|		|
|	harbor_bb_idx_data_ml	|	INDEX_NAME	|	string	|	20	|		|		|		|		|		|	// In-case of Update<br>Table Name : DBO.BB_BENCHMARK_PRICE_FINAL<br>Condition : PRICE_DATE = PRICE_DATE_out AND BLOOMBERG_SYMBOL = BLOOMBERG_FYM<br>Output Column: PBL_ID<br><br>//In-case of insert<br>Table Name: DBO.PRF_BENCHMARK_LIST<br>Condition: BLOOMBERG_SYMBOL = BLOOMBERG_FYM_in<br>Output COlumn: ID	|		|	Join the 2 sources with DATE_VALUE_table_in = PRICE_DATE_file_in	|	BB_BENCHMARK_PRICE_FINAL	|	PBL_ID	|	number	|	15	|		|		|
|	harbor_bb_idx_data_ml	|	PRICE_DATE	|	string	|	14	|		|		|		|	"DATE_VALUE from ""Ref_Dates"" Table"	|		|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	PRICE_DATE	|	date	|	19	|		|		|
|	harbor_bb_idx_data_ml	|	LAST_PRICE	|	string	|	16	|		|		|		|		|	"ltrim(rtrim(INDEX_NAME_in)) - From ""harbor_bb_idx_data_ml"" table "	|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	BLOOMBERG_SYMBOL	|	varchar2	|	12	|		|		|
|	harbor_bb_idx_data_ml	|	NOT_USED	|	string	|	5	|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	OPEN_PRICE	|	"number(p,s)"	|	19	|		|		|
|		|		|		|		|		|		|		|		|	"TO_DECIMAL(LAST_PRICE_v) -From ""harbor_bb_idx_data_ml"" table"	|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	LAST_PRICE	|	"number(p,s)"	|	19	|		|		|
|	Refer SQ	|	DATE_VALUE	|	Date	|		|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	HIGH_PRICE	|	"number(p,s)"	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	LOW_PRICE	|	"number(p,s)"	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	INSERT_USER	|	varchar2	|	30	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	INSERT_TIMESTAMP	|	date	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_FINAL	|	UPDATE_TIMESTAMP	|	date	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
