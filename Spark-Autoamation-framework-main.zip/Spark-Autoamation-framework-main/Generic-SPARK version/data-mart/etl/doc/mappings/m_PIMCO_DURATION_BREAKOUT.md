|	Source File Name	|	Column Name	|	Data Type	|	Length	|	Precision	|	Nullable	|	PK	|	BK	|		|		|		|		|	Target Table Name	|	Column Name	|	Data Type	|	Length	|	Nullable	|	PK	|
|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|	Refer SQ	|	ASOF_DATE	|	string	|	25	|		|		|		|	SEQ Number	|		|	Table Name : PIMCO_DURATION_BREAKOUT<br>Condition: DUR_BUCKT_KEY = DUR_BUCKET_KEY_in AND FUND_COMPST_KEY = FUND_COMPST_KEY_in AND DAY_KEY = DAY_KEY_in<br>Output Column: PMC_DUR_BRK_OUT_KEY	|		|	Update if record already present	|		|	PMC_DUR_BRK_OUT_KEY	|	"number(p,s)"	|	10	|		|		|
|		|	ACCT_NO	|	string	|	25	|		|		|		|		|		|	:LKP.LKP_DURATION_BUCKET_KEY(LTRIM(RTRIM(BUCKET)))<br><br>Table Name: HDM.PIMCO_DURATION_BUCKET<br>Condition: DUR_BUCKT_NM = DUR_BUCKT_NM_in<br>Output Column: DUR_BUCKT_KEY	|		|		|		|	DUR_BUCKT_KEY	|	"number(p,s)"	|	10	|		|		|
|		|	BUCKET	|	string	|	25	|		|		|		|		|		|	:LKP.LKP_FND_COMPST_KEY(ACCT_NO)<br>Table Name: HDM.PIMCO_ACCOUNT_REFERENCE<br>Condition: PMC_ACCT_NBR = PMC_ACCT_NBR_IN<br>Output Column: FUND_COMPST_KEY	|		|		|		|	FUND_COMPST_KEY	|	"number(p,s)"	|	10	|		|		|
|		|	ACCT_DUR_PCT	|	string	|	25	|		|		|		|		|		|	:LKP.LKP_DAY_KEY(ASOF_DATE_out)<br><br>Table Name: HDM.CALENDAR <br>Condition: CAL_DAY = CAL_DAY_in<br>Output Column: DAY_KEY	|		|		|		|	DAY_KEY	|	"number(p,s)"	|	10	|		|		|
|		|	ACCT_DWE	|	string	|	25	|		|		|		|		|	TO_DECIMAL(ACCT_DUR_PCT)/100	|		|		|		|		|	ACCT_DUR_PCT	|	number	|	15	|		|		|
|		|	BM_DUR_PCT	|	string	|	25	|		|		|		|		|	TO_DECIMAL(ACCT_DWE)	|		|		|		|		|	ACCT_DWE	|	number	|	15	|		|		|
|		|	BM_DWE	|	string	|	25	|		|		|		|		|	TO_DECIMAL(BM_DUR_PCT)/100	|		|		|		|		|	BMK_DUR_PCT	|	number	|	15	|		|		|
|		|	VAR_DUR_PCT	|	string	|	25	|		|		|		|		|	TO_DECIMAL(BM_DWE)	|		|		|		|		|	BMK_DWE	|	number	|	15	|		|		|
|		|	VAR_DWE	|	string	|	25	|		|		|		|		|	TO_DECIMAL(VAR_DUR_PCT)/100	|		|		|		|		|	VAR_DUR_PCT	|	number	|	15	|		|		|
|		|		|		|		|		|		|		|		|	TO_DECIMAL(VAR_DWE)	|		|		|		|		|	VAR_DWE	|	number	|	15	|		|		|
|		|		|		|		|		|		|		|		|	Y'	|		|		|		|		|	CURR_ROW_FLG	|	nvarchar2	|	1	|		|		|
|		|		|		|		|		|		|		|		|	SYSDATE	|		|		|		|		|	ROW_STRT_DTTM	|	date	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|	ROW_STOP_DTTM	|	date	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|	ETL_LOAD_CYC_KEY	|	"number(p,s)"	|	10	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|	SRC_SYS_ID	|	number	|	15	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
