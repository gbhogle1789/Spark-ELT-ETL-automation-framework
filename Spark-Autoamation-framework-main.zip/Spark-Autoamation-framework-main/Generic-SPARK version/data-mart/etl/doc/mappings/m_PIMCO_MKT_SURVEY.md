|	Source File Name	|	Column Name	|	Data Type	|	Length	|	Precision	|	Nullable	|	PK	|	BK	|		|		|		|		|	Target Table Name	|	Column Name	|	Data Type	|	Length	|	Nullable	|	PK	|
|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|
|		|		|		|		|		|		|		|		|		|		|	Update if record already present	|		|		|		|		|		|		|		|
|	STG_PIMCO_MKT_SURVEY	|	ASOF_DATE	|	nstring	|	30	|		|		|		|	SEQ Number	|		|	Table Name: HDM.PIMCO_MKT_SURVEY<br>Condition: DAY_KEY = DAY_KEY1 AND FUND_COMPST_KEY = FUND_COMPST_KEY1 AND MKT_CNTR_KEY = MKT_CNTR_KEY1<br>Output Column: MKT_SRVY_KEY	|		|		|	PIMCO_MKT_SURVEY	|	MKT_SRVY_KEY	|	"number(p,s)"	|	10	|		|		|
|	STG_PIMCO_MKT_SURVEY	|	ACCT_NO	|	nstring	|	30	|		|		|		|		|		|	Tabke Name : HDM.CALENDAR<br>Condition: CAL_DAY = ASOF_DATE_out<br>Ouput Column: DAY_KEY	|		|		|	PIMCO_MKT_SURVEY	|	DAY_KEY	|	"number(p,s)"	|	10	|		|		|
|	STG_PIMCO_MKT_SURVEY	|	COUNTRY	|	nstring	|	100	|		|		|		|		|		|	Table Name: HDM.PIMCO_ACCOUNT_REFERENCE<br>Condiion PMC_ACCT_NBR = ACCT_NO<br>Output Column:FUND_COMPST_KEY<br>	|		|		|	PIMCO_MKT_SURVEY	|	FUND_COMPST_KEY	|	"number(p,s)"	|	10	|		|		|
|	STG_PIMCO_MKT_SURVEY	|	PORTFOLIO_COUNTRY_PERCENT	|	nstring	|	30	|		|		|		|		|		|	Table Name: HDM.PIMCO_MKT_COUNTRY<br>Condition : CRTY_NM = COUNTRY <br>Output Column: MKT_CNTR_KEY<br>	|		|		|	PIMCO_MKT_SURVEY	|	MKT_CNTR_KEY	|	"number(p,s)"	|	10	|		|		|
|	STG_PIMCO_MKT_SURVEY	|	PORTFOLIO_CURRENCY_PERCENT	|	nstring	|	30	|		|		|		|		|	"TO_DECIMAL(RTRIM(PORTFOLIO_COUNTRY_PERCENT,'%'))/100'"	|		|		|		|	PIMCO_MKT_SURVEY	|	FUND_CRTY_PCT	|	number	|	15	|		|		|
|	STG_PIMCO_MKT_SURVEY	|	BENCHMARK_COUNTRY_PERCENT	|	nstring	|	30	|		|		|		|		|	"TO_DECIMAL(RTRIM(PORTFOLIO_CURRENCY_PERCENT,'%'))/100"	|		|		|		|	PIMCO_MKT_SURVEY	|	FUND_CURRCY_PCT	|	number	|	15	|		|		|
|	STG_PIMCO_MKT_SURVEY	|	BENCHMARK_CURRENCY_PERCENT	|	nstring	|	30	|		|		|		|		|	"TO_DECIMAL(RTRIM(BENCHMARK_COUNTRY_PERCENT,'%'))/100"	|		|		|		|	PIMCO_MKT_SURVEY	|	BMK_CRTY_PCT	|	number	|	15	|		|		|
|		|		|		|		|		|		|		|		|	"TO_DECIMAL(RTRIM(BENCHMARK_CURRENCY_PERCENT,'%'))/100"	|		|		|		|	PIMCO_MKT_SURVEY	|	BMK_CURRCY_PCT	|	number	|	15	|		|		|
|		|		|		|		|		|		|		|		|	Y'	|		|		|		|	PIMCO_MKT_SURVEY	|	CURR_ROW_FLG	|	nvarchar2	|	1	|		|		|
|		|		|		|		|		|		|		|		|	SYSDATE	|		|		|		|	PIMCO_MKT_SURVEY	|	ROW_STRT_DTTM	|	date	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|	PIMCO_MKT_SURVEY	|	ROW_STOP_DTTM	|	date	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|	PIMCO_MKT_SURVEY	|	ETL_LOAD_CYC_KEY	|	"number(p,s)"	|	10	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|	PIMCO_MKT_SURVEY	|	SRC_SYS_ID	|	number	|	15	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
