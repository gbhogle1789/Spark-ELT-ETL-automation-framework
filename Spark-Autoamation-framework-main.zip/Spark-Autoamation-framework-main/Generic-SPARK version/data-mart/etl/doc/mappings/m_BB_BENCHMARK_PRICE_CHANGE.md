|	Source File Name	|	Column Name	|	Data Type	|	Length	|	Precision	|	Nullable	|	PK	|	BK	|		|		|		|		|	Target Table Name	|	Column Name	|	Data Type	|	Length	|	Nullable	|	PK	|
|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|
|		|		|		|		|		|		|		|		|		|		|	Update the record if already exists	|		|		|		|		|		|		|		|
|	bb_hpc	|	BENCHMARK_NAME	|	string	|	50	|		|		|		|		|	"substr(BENCHMARK_NAME,1,length(BENCHMARK_NAME)-7)"	|		|		|	ltrim(rtrim(FIELD_NAME))='PX_LAST'	|	BB_BENCHMARK_PRICE_CHANGE	|	BLOOMBERG_SYMBOL	|	varchar2	|	12	|		|	Y	|
|	bb_hpc	|	FIELD_NAME	|	string	|	20	|		|		|		|		|	"to_date(PRICE_DATE,'YYYYMMDD')"	|		|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	PRICE_DATE	|	date	|	19	|		|	Y	|
|	bb_hpc	|	OLD_PRICE	|	string	|	16	|		|		|		|		|	"TO_DECIMAL(OLD_PRICE,6)"	|		|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	OLD_LAST_PRICE	|	"number(p,s)"	|	19	|		|		|
|	bb_hpc	|	PRICE_DATE	|	string	|	8	|		|		|		|		|	"to_decimal(NEW_PRICE,6)"	|		|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	NEW_LAST_PRICE	|	"number(p,s)"	|	19	|		|		|
|	bb_hpc	|	NEW_PRICE	|	string	|	16	|		|		|		|		|	"to_date(CORRECTION_DATE,'YYYYMMDD')"	|		|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	BB_UPDATE_DATE	|	date	|	19	|		|		|
|	bb_hpc	|	CORRECTION_DATE	|	string	|	8	|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	INSERT_USER	|	varchar2	|	30	|		|		|
|	bb_hpc	|	CORRECTION_TIME	|	string	|	5	|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	INSERT_TIMESTAMP	|	date	|	19	|		|		|
|	bb_hpc	|	EXCHANGE_INDICATOR	|	string	|	20	|		|		|		|		|		|		|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	UPDATE_TIMESTAMP	|	date	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|	Table Name: PRF_BENCHMARK_LIST <br>Condition: BLOOMBERG_SYMBOL = BLOOMBERG_SYMBOL_in <br>Output Column: ID	|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	PBL_ID	|	number	|	15	|		|		|
|		|		|		|		|		|		|		|		|		|	Table Name: PRF_BENCHMARK_PRICE <br>Condition: PBL_ID = PBL_ID_in AND PRICE_DATE = PRICE_DATE1<br>Output Column: PRICE	|		|		|	BB_BENCHMARK_PRICE_CHANGE	|	LAST_PRICE_IN_TABLE	|	"number(p,s)"	|	19	|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
