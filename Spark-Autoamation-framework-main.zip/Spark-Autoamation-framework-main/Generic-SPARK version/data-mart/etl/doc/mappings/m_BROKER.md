|	Source File Name	|	Column Name	|	Data Type	|	Length	|	Nullable	|	PK	|	BK	|		|		|		|		|	Table Name	|	Target Table Name	|	Data Type	|	Length	|	Nullable	|	PK	|		|
|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|
|	INTACCT	|	FUND	|	String	|	7	|		|		|		|		|	Increment the Key value by '1' for each new record	|	Increment the Key value by '1' for each new record	|	"If the record already present in 'Broker' table for the combination of BRKR_NM, COMPST_NM and BRKR_ACCT_NBR Then Update it otherwise insert the record"	|	BROKER	|	BRKR_KEY	|	"number(p,s)"	|	10	|		|	Y	|		|
|	INTACCT	|	BRKR_NM	|	String	|	150	|		|		|		|		|	UPPER(LTRIM(RTRIM(POSITION_TYP)))	|	"SELECT HDM.POSITION_TYPE.POSN_TYPE_KEY AS POSN_TYPE_KEY,<br>       LTRIM (RTRIM (HDM.POSITION_TYPE.POSN_CD)) AS POSN_CD<br>  FROM HDM.POSITION_TYPE<br><br>Condition : POSN_CD = POSITION_TYP_OUT  (from source)"	|		|	BROKER	|	POSN_TYPE_KEY	|	"number(p,s)"	|	10	|		|		|		|
|	INTACCT	|	POSITION_TYP	|	String	|	8	|		|		|		|		|	LTRIM(RTRIM(BRKR_NM))	|		|		|	BROKER	|	BRKR_NM	|	varchar2	|	100	|		|		|		|
|	INTACCT	|	BRKR_ACCT_ID	|	String	|	100	|		|		|		|		|	UPPER(LTRIM(RTRIM(FUND)))	|		|		|	BROKER	|	ST_STR_NBR	|	varchar2	|	25	|		|		|		|
|		|		|		|		|		|		|		|	If FUND_OUT is 'GB35' then 'Harbor Cayman Commodity Fund Ltd' Else FUND_NM	|	"decode(FUND_OUT,'GB35','Harbor Cayman Commodity Fund Ltd',FUND_NM)"	|	"//FUND_NM<br>SELECT LTRIM (RTRIM (HDM.FUND.FUND_NM)) AS FUND_NM,<br>       HDM.FUND.ST_STR_FUND_NBR as ST_STR_FUND_NBR<br>  FROM HDM.FUND<br><br>Condition : ST_STR_FUND_NBR = FUND_OUT"	|		|	BROKER	|	COMPST_NM	|	varchar2	|	100	|		|		|		|
|		|		|		|		|		|		|		|	BRKR_ACCT_ID' from source	|	BRKR_ACCT_ID	|		|		|	BROKER	|	BRKR_ACCT_NBR	|	varchar2	|	100	|		|		|		|
|		|		|		|		|		|		|		|	Default to 'Y'	|	Y'	|		|		|	BROKER	|	CURR_ROW_FLG	|	varchar2	|	1	|		|		|		|
|		|		|		|		|		|		|		|	Current Date	|	SYSDATE	|		|		|	BROKER	|	ROW_STRT_DTTM	|	date	|	19	|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|	BROKER	|	ROW_STOP_DTTM	|	date	|	19	|		|		|		|
|		|		|		|		|		|		|		|		|	Value from Param file	|	$$etlcyckey	|		|	BROKER	|	ETL_LOAD_CYC_KEY	|	"number(p,s)"	|	10	|		|		|		|
|		|		|		|		|		|		|		|		|	Default to '4'	|	4'	|		|	BROKER	|	SRC_SYS_ID	|	number	|	15	|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
