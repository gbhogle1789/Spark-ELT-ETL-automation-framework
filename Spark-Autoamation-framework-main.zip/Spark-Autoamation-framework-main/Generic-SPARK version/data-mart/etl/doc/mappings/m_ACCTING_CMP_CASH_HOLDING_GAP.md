|	Source File Name	|	Column Name	|	Data Type	|	Length	|	Precision	|	Nullable	|	PK	|	BK	|		|		|		|		|	Target Table Name	|	Column Name	|	Data Type	|	Length	|	Nullable	|	PK	|
|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|	---	|
|		|		|		|		|		|		|		|		|		|		|	Update the record if its already present	|		|		|		|		|		|		|		|
|	Refer SQ	|	SSB_FUND_NBR	|	string	|	5	|		|		|		|	SSB_FUND_NBR_in	|		|	Table Name: DBO.ACCTING_CMP_CASH_HOLDING <br>Condition: SSB_FUND_NBR = SSB_FUND_NBR_in AND CASH_DATE = NEXTDAY <br>Output Column: SSB_FUND_NBR 	|		|	FLG_BUSINESS_DAY=''	|	ACCTING_CMP_CASH_HOLDING	|	SSB_FUND_NBR	|	varchar2	|	5	|		|		|
|		|	CASH_DATE	|	date/time	|	29	|		|		|		|		|	"ADD_TO_DATE(<br>trunc(to_date(CASH_DATE_in,'mm/dd/yyyy')),'DD',v)"	|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	CASH_DATE	|	date	|	19	|		|		|
|		|	SSB_FUND_NBR	|	string	|	5	|		|		|		|		|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	CASH	|	number	|	15	|		|		|
|		|	CASH_DATE	|	date/time	|	29	|		|		|		|		|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	SHORT_TERM	|	number	|	15	|		|		|
|		|	CASH	|	double	|	15	|		|		|		|		|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	REC	|	number	|	15	|		|		|
|		|	SHORT_TERM	|	double	|	15	|		|		|		|		|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	PAYABLE	|	number	|	15	|		|		|
|		|	REC	|	double	|	15	|		|		|		|	NET_SHARES_in	|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	NET_SHARES	|	number	|	15	|		|		|
|		|	PAYABLE	|	double	|	15	|		|		|		|	NET_ASSETS_in	|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	NET_ASSETS	|	number	|	15	|		|		|
|		|	NET_SHARES	|	double	|	15	|		|		|		|		|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	INSERT_TIMESTAMP	|	date	|	19	|		|		|
|		|	NET_ASSETS	|	double	|	15	|		|		|		|		|		|		|		|		|	ACCTING_CMP_CASH_HOLDING	|	UPDATE_TIMESTAMP	|	date	|	19	|		|		|
|		|	INSERT_TIMESTAMP	|	date/time	|	29	|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|	UPDATE_TIMESTAMP	|	date/time	|	29	|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|		|
