This folder contains documentation for existing mapping from informatica
