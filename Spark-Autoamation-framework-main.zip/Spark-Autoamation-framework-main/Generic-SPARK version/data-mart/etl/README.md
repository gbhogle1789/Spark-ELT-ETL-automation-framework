# ETL

Extraction, transformation, computation and loading of data from the data lake into the data mart.

This include

- data lake file format custom handling
- catalog
- computation and intermediary data creation
- loading of data into final data mart
